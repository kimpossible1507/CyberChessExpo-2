
# CyberChess (Expo / React Native)

App de xadrez estilo **Cyberpunk** com modo noturno, múltiplos temas de tabuleiro e **personalização de peças via imagens**. 
Foi pensado para rodar com **Expo SDK 51** (ou superior compatível).

## Recursos principais
- Tabuleiro animado com destaques neon.
- Regras oficiais com **chess.js**.
- Modo Jogador vs Jogador local e modo vs CPU simples (movimentos aleatórios; base para IA futura).
- **Gerenciador de Skins**: escolha imagens da galeria para cada peça (K, Q, R, B, N, P) para brancas e pretas.
- **Pastas de assets**: substitua as imagens em `assets/pieces/skins/default/` ou crie novas subpastas e selecione no app.
- Múltiplos temas de tabuleiro: *Neon Grid*, *Carbon*, *Holo*.
- Preferências gravadas em AsyncStorage (orientação, coordenadas, animação, glow, tema).

## Como rodar (sem PC local)
1. Crie uma conta gratuita em https://expo.dev
2. No seu tablet/celular, instale o **Expo Go** pela Play Store.
3. Envie este projeto para um repositório (GitHub) ou suba um `.zip` descompactado para um serviço (StackBlitz/CodeSandbox com suporte a Node) e conecte ao Expo.
4. No terminal online, rode:  
   ```bash
   npm install
   npx expo install
   npm run start
   ```
5. Abra o **Expo Go** e escaneie o QR code para abrir o app.

## Gerar APK (Build na nuvem)
- Use **EAS Build**:  
  ```bash
  npm install -g eas-cli
  eas login
  eas build:configure
  eas build --platform android
  ```
- Após finalizar, baixe o APK pelo painel do Expo.

## Onde colocar suas imagens das peças
- Substitua os PNGs em `assets/pieces/skins/default/` **antes** do build, ou
- No app, vá em **Skins** e selecione imagens da **galeria** para cada peça. As escolhas são salvas localmente.

## Observação sobre versões
Use `npx expo install <pacote>` para alinhar versões com a SDK atual caso algo mude.
